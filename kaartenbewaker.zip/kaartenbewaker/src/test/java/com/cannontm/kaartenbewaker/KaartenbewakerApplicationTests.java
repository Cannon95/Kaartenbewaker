package com.cannontm.kaartenbewaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaartenbewakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
