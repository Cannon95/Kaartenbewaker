package com.cannontm.kaartenbewaker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KaartenbewakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KaartenbewakerApplication.class, args);
	}

}
